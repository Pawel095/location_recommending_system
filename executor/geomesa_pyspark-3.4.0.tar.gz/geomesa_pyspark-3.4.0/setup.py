from setuptools import setup, find_packages

setup(
    name='geomesa_pyspark',
    version='3.4.0',
    url='http://www.geomesa.org',
    packages=find_packages(),
    install_requires=['pytz', 'shapely']
)
